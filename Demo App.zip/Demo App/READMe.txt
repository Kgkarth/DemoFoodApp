#Please find the attached source code for the Database connection and 
the entire Project of the App in Android Studio.
#I've used Xampp app on desptop to connect to the MySQL databse in phpMyadmin.
#You might have to download Xampp to allow access for apache and MySql to Database.  